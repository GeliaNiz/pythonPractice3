import setuptools
setuptools.setup(
    name = 'function',
    version = '0.0.1',
    author = 'AngelNiz',
    author_email = 'angelinanizam@gmail.com',
    description = 'Task with creation of package from practice 3',
    packages = setuptools.find_packages()

)